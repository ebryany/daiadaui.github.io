<?php
$telegram_id = "5689730827";
$id_bot = "5960409906:AAGy27MHkAng_WUufd-chbXVQ2YRHb-VB4g";
?>
